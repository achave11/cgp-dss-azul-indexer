from .select_command import SelectCommand
from .list_areas_command import ListAreasCommand
from .list_area_command import ListAreaCommand
from .upload_command import UploadCommand
from .forget_command import ForgetCommand
from .common import UploadCLICommand


def add_commands(subparsers):
    upload_parser = subparsers.add_parser('upload', help="Upload data to HCA")
    upload_subparsers = upload_parser.add_subparsers()

    help_parser = upload_subparsers.add_parser('help',
                                               description="Display list of upload commands.")

    def _help(args):
        upload_parser.print_help()

    upload_parser.set_defaults(entry_point=_help)
    help_parser.set_defaults(entry_point=_help)

    SelectCommand.add_parser(upload_subparsers)
    UploadCommand.add_parser(upload_subparsers)
    ListAreaCommand.add_parser(upload_subparsers)
    ListAreasCommand.add_parser(upload_subparsers)
    ForgetCommand.add_parser(upload_subparsers)
