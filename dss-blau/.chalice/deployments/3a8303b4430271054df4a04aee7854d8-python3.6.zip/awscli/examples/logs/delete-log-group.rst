The following command deletes a log group named ``my-logs``::

  aws logs delete-log-group --log-group-name my-logs
