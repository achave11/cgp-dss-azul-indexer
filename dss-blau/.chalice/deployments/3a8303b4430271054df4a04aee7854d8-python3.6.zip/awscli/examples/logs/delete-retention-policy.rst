The following command removes the retention policy that has previously been applied to a log group named ``my-logs``::

  aws logs delete-retention-policy --log-group-name my-logs
